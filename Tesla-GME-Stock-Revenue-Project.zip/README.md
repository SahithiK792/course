Tesla and GameStop Stock & Revenue Dashboard Project
====================================================

Contents:
- Final_Stock_Revenue_Project.ipynb  (Jupyter notebook with full code and example executed outputs)
- PDFs/ (included PDFs for individual questions)
- Screenshots/ (placeholders for you to add real screenshots)
- README.md (this file)

Notes:
- The notebook includes full code for extracting data with yfinance and web scraping, plus plotting code.
- The outputs included are example executed outputs using placeholder/sample data and saved plots (since live web access is not available in this environment).
- Replace placeholder sections with your real screenshots and data if needed before submitting to your instructor.
